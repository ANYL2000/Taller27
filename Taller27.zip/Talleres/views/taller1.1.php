<?php

//include('sesion_mantenida.php');
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}


$conexion->query("SET NAMES 'utf8'");
$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$con=mysqli_connect($host,$db_username,$db_password,$db_name);

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 


}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller1.1.php';</script>";
}

//idTalleres,NombreTallerista,NombreTaller, Calendario, Capacidad, Turno, Tipo,Dia,Registrados,Lugares_Faltantes

//session_start();
// Establecer tiempo de vida de la sesión en segundos
$inactividad = 300;


$query =$conexion->prepare("SELECT * FROM mostrar_talleres WHERE Calendario='$año';");

$query->execute();
$resultado =$query->fetchAll();

 //consultar cuenta prestador
 $cuenta_prestador =$conexion->prepare("SELECT * FROM cuentas_usuarios WHERE Usuario='Prestador'");

 $cuenta_prestador->execute();
 $resultado_cuenta_prestador =$cuenta_prestador->fetchAll();
 
 foreach($resultado_cuenta_prestador as $cuenta_usuario_prestador):
 $contra_prestador = $cuenta_usuario_prestador['Contra'];
 endforeach;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_taller1.1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<?php include 'header_taller.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    
<div id="modal_tiempo_excedido">

</div>


<div class="fondo">




<a class="btn btn-primary nuevo" href="taller1.php">Registrar Nuevo Taller</a>

<button type='submit' class='btn btn-success cuentas' id='nuevo_estudiante' name='nuevo_estudiante' data-toggle='modal' data-target="#nuevousuarioModal">Agregar alumno</button>

<button type='submit' class='btn btn-secondary cuentas' id='cuentas' name='cuentas' data-toggle='modal' data-target="#cuentasModal">Cuentas de usuarios</button>

<h1 class="titulo_taller">Talleres registrados</h1>



   <div class="input-group" style="width:215px;">
              <label for="" id="labelbuscar_calendario" style="display:flex;"> 
              <input id="buscar_calendario" name = "buscar_calendario"  type="text" Class="form-control" placeholder=" ">
              <span id="spanbuscar_calendario">Buscar por Calendario</span>   
            
                 <div class="input-group-append">
               <button id="btnbuscar_calendario" class="btn btn-primary" type="button" > <span class="fa-solid fa-magnifying-glass"></span> </button>
               </div>
               </label>
              </div>

              
              <div id="datos_buscar_calendario">

</div>


<table class="table-responsive calendario_vigente" id="calendario_vigente">
    <thead>
<tr class="fila_principal">

    <td>Nombre del taller</td>
    <td>Calendario</td>
    <td>Capacidad</td>
    <td>Turno</td>
    <td>Tipo</td>
    <td>Dia</td>
    <td>Registrados</td>
    <td>Faltantes</td>
</tr>
</thead>
<?php  foreach($resultado as $taller):  ?>

    <!--taller1.2.php?idtaller='<?php //echo $taller['NombreTaller']?>'-->
   

<tr class="filas_secundarias" id="color_filas" >

    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['NombreTaller']);?> </a></td>
    <td> <a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"> <?php echo utf8_encode($taller['Calendario']);?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Capacidad']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Turno']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Tipo']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Dia']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Registrados']?></a></td>
    <td><a href="taller1.2.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><?php echo $taller['Lugares_Faltantes']?></a></td>
</tr>


<?php   endforeach; ?>

</table>



<!--Seccion del modal de la informacion de las cuentas-->

<!-- Modal Cuentas-->
<div class="modal fade" id="cuentasModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cuentas de usuarios</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="taller1.1.php" method="POST"> <!--fa-solid fa-pencil-slash-->
       
         
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Administrador</label>
            <div class="input-group">
      <input id="recipient_contra_admin" name = "recipient_contra_admin"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
      <div class="input-group-append">
            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPasswordAdmin()" > <span class="fa fa-eye-slash icon_admin"></span> </button>
            <button type="button" class="btn btn-light editar_contra_admin" id="editar_contra_admin" name="editar_contra_admin" onclick="editar_campos_admin()"><span class="fa fa-pencil edit"></span></button>
          </div>
    </div>
            <!--<input type="text" class="form-control" id="recipient_contra_admin"  name = "recipient_contra_admin" value="<?php //echo $fila["Nombre"]; ?>" required autocomplete="off">-->

          </div>
          <div class="form-group">
                   <label for="recipient-name" class="col-form-label">Prestador</label>
          
                   <div class="input-group">
                 <input id="recipient_contra_prestador" name = "recipient_contra_prestador"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
                <div class="input-group-append">
               <button id="show_password2" class="btn btn-primary" type="button" onclick="mostrarPasswordPrestador()" > <span class="fa fa-eye-slash icon_prestador"></span> </button>
               <button type="button" class="btn btn-light editar_contra_prestador" id="editar_contra_prestador" name="editar_contra_prestador" onclick="editar_campos_prestador()"><span class="fa fa-pencil edit"></span></button>
              </div>
              </div>
          </div>
         
        
          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary guardar_cambios" id="btncuentas" name="btncuentas" hidden="true" onclick="desbloquear_campos()">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>


<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Agregar datos de estudiante nuevo-->
<div class="modal fade" id="nuevousuarioModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar alumno</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Codigo:</label>
          
            <input type="text" class="form-control" id="recipient_codigo" name="recipient_codigo"  required autocomplete="off">
          </div> 
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nombre Completo: (comenzando por apellidos)</label>
            <input type="text" class="form-control" id="recipient_nombre"  name = "recipient_nombre"  required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Carrera:</label>
            <input type="text" class="form-control" id="recipient_carrera" name="recipient_carrera"  required autocomplete="off">
          </div>

          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary" id="btnagregar" name="btnagregar">Agregar ahora</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>


</div><!--div de class fondo-->

<!--Habilitar campos y mostrar texto de los inputs del modal de las cuentas de usuario-->
<script type="text/javascript">
function mostrarPasswordAdmin(){
		var cambio = document.getElementById("recipient_contra_admin");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_admin').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_admin').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 

  function mostrarPasswordPrestador(){
		var cambio = document.getElementById("recipient_contra_prestador");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_prestador').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_prestador').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 
	
  function editar_campos_admin(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_prestador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio1.disabled == true ){

      cambio3_boton.hidden = false;
			cambio1.disabled = false;
     
			$('.editar_contra_admin').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio2.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio1.disabled = true;
     
      $('.editar_contra_admin').removeClass('btn btn-dark').addClass('btn btn-light');
		}
  }

  function editar_campos_prestador(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_prestador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio2.disabled == true){
      cambio3_boton.hidden = false;
      cambio2.disabled = false;
			$('.editar_contra_prestador').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio1.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio2.disabled = true;
      $('.editar_contra_prestador').removeClass('btn btn-dark').addClass('btn btn-light');
		}

  }

  function desbloquear_campos(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    cambio1.disabled = false;
    var cambio2 = document.getElementById("recipient_contra_prestador");
    cambio2.disabled = false;
 
  }

</script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>
<?php


//if para hacer las acciones al presionar boton de guardar cambios del modal de cuentas de usuario
if(isset($_POST['btncuentas'])){


  // se guardar los valores en variables
  $admin_contra = $_POST['recipient_contra_admin'];

  $admin_contra_encrypt = sha1($_POST['recipient_contra_admin']);

  $prestador_contra = $_POST['recipient_contra_prestador'];
  $prestador_contra_encrypt = sha1($_POST['recipient_contra_prestador']);
  
  $validar_contraseñas = "SELECT * FROM cuentas_usuarios";

  $contraseñas = mysqli_query($con,$validar_contraseñas);

  if(!empty($admin_contra)||!empty($prestador_contra)){
  
 if($admin_contra!=$prestador_contra){ //validar que no sean iguales las contraseñas de los inputs

 

  $i=0;    
  while($filas_cuenta = mysqli_fetch_array($contraseñas)){ //while para guardar contraseñas y usuarios de la base datos en variables
    
    $user[$i] = $filas_cuenta['Usuario'];
   $password[$i] = $filas_cuenta['Contra'];
   
   $i++;
  }



 //if para validar que las contraseñas escritas en los inputs no sean las contraseñas de otro usuario en la base de datos
if(($admin_contra!=$password[1]&&$prestador_contra_encrypt!=$password[0])||empty($admin_contra)||empty($prestador_contra)){


  if($admin_contra!=$password[1]){ //if para validar que la contraseña escrita de administrador no sea la del prestador en la BD

  if(!empty($admin_contra)){ //entra si se agrega una contraseña de administrador 

if($admin_contra_encrypt!=$password[0]){//if para saber si la contraseña del administrador es diferente al de la base de datos

  //se actualiza el registro de la cuenta administrador
  $con->query("UPDATE cuentas_usuarios SET Contra = '$admin_contra_encrypt' WHERE Usuario= '$user[0]'");

  if(!empty($prestador_contra)){ //if para validar si la del prestador no  este vacio
   
    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
  }

  if($con){ //se muestra la ventana de exito al actualizar las contraseñas
    echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
  }


}else{ //else que muestra un error de que la contraseña de administrador es la misma que la base de datos y no ha cambiado
  
  echo '<script>alertaeNoti("Esta contraseña de administrador es la que esta asignada actualmente")</script>';
}


  }
  }else{ //else para mostrar error de que la contraseña de administrador escrita es igual al de prestador
    echo '<script>alertaeNoti("Esta contraseña de administrador es la que esta asignada actualmente al prestador")</script>';

  }

  //if para validar que la contraseña de prestador escrita no sea igual al de administrador en la BD
  if($prestador_contra_encrypt!=$password[0]){

  if(!empty($prestador_contra)){ //if para validar que no este vacio el campo de contraseña de prestador
  
    if($prestador_contra!=$password[1]){ //if para saber si la contraseña del prestador es diferente al de la base de datos
   
    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
    if($con){ //se muestra la ventana de exito al actualizar las contraseñas
      echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
    }
  }

  }
}else{//else para mostrar error de que la contraseña de prestador escrita es igual al de administrador
  echo '<script>alertaeNoti("Esta contraseña de prestador esta siendo usada actualmente por otro")</script>';
}
   

  }else{ //else para mostrar advertencia sobre el intercambio de contraseñas
    echo '<script>alertaeNotiwarning("No es recomendable intercambiar las contraseñas")</script>';
  }
 }else{  //else para mostrar error de contraseñas iguales
  echo '<script>alertaeNoti("Las contraseñas no deben ser iguales entre usuarios")</script>';
 }
  }else{
    echo '<script>alertaeNoti("Los campos estan vacios")</script>';
  }

}
////////////////////////////////////////////////////////////////////////////////////////

//if para hacer acciones al presionar boton de agregar ahora del modal agregar alumno
if(isset($_POST['btnagregar'])){

  //se guardan los valores en variables
$codigo = $_POST['recipient_codigo'];
$nombre = $_POST['recipient_nombre'];
$carrera = $_POST['recipient_carrera'];
if (strpos($codigo, "'")==false){ 
//consulta para validar si ya existe alguien con el codigo que se intenta agregar
$validar_repetidos = "SELECT * FROM personas WHERE codigo = '$codigo'";

$resultado_repetidos = mysqli_query($con,$validar_repetidos);


if(mysqli_num_rows($resultado_repetidos)==0){ //if para validar que no se encontro resultado de la consulta

  if (strpos($codigo, " ")){ //if para validar que el codigo escrito no tenga espacios vacios
    echo '<script>alertaeNoti("El codigo no debe tener espacios vacios")</script>';
  }else{ //else para agregar al nuevo alumno

    //if para validar que nomas esten permitidos los numeros y letras mayusculas en el codigo de alumno
    if (preg_match("/^[A-Z0-9]*$/i", $codigo)) {

      if(strlen($codigo)>=8){
    //se agregan los datos a la BD en la tabla personas
    $con->query("INSERT INTO personas (codigo,nombre,carrera) values ('$codigo','$nombre','$carrera')");

    if($con){ //se muestra la ventana de exito al agregar el nuevo alumno
      echo '<script>alertaNoti("Se ha agregado con exito")</script>';
    }
  }else{
    echo '<script>alertaeNoti("El codigo debe tener 8 caracteres o más")</script>';
  }
  }else{
    echo '<script>alertaeNoti("El codigo solo permite números y letras")</script>';
  }
  }
}else{ //else para mostrar error de que ya existe el codigo en la BD
  echo '<script>alertaeNoti("Ese codigo ya está en el sistema")</script>';
}

}
}

?>

<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../assets/js/Buscar.js"></script>

<?php
//Comprobar si $_SESSION["timeout"] está establecida
/*if(isset($_SESSION["timeout"])){
  // Calcular el tiempo de vida de la sesión (TTL = Time To Live)
  $sessionTTL = time() - $_SESSION["timeout"];
  if($sessionTTL > $inactividad){
      session_destroy();
      echo "<script> 

      $.ajax({
        url: 'tiempo_excedido_modal.php',
      type: 'POST',
      dataType: 'html',
      //data: {buscar: buscar},
      
      })
      .done(function(respuesta){
        $('#modal_tiempo_excedido').html(respuesta);
      })
      .fail(function(){
      
      })
      
      </script>";
     
      echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";
  }
}*/
?>

</body>
</html>
<?php $con->close();  $conexion = null;?>