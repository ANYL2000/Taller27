<?php

//include('sesion_mantenida.php');
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion


if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}


$conexion->query("SET NAMES 'utf8'");
$conexion = connect($host, $port, $db_name, $db_username, $db_password);

date_default_timezone_set('America/Mexico_City');   

$año = date('Y');
$mes = date('m');



if($mes>=1&&$mes<=6){
  $año.="A";
 
  $fecha = "Enero-Junio";
 


}else if($mes>=7&&$mes<=12){
  $año.="B";
 
  $fecha = "Julio-Diciembre";
 
 

}else if($mes>12||$mes<1){

  echo "<script>alert('Configure correctamente su zona horaria');</script>";
  echo "<script>window.location='taller_servicio_social.php';</script>";
}

//idTalleres,NombreTallerista,NombreTaller, Calendario, Capacidad, Turno, Tipo,Dia,Registrados,Lugares_Faltantes

//session_start();
// Establecer tiempo de vida de la sesión en segundos
$inactividad = 300;


$query =$conexion->prepare("SELECT * FROM mostrar_talleres WHERE Calendario='$año';");

$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_talleres_servicio_social.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

<?php include 'header_prestador.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    
<!--<div id="modal_tiempo_excedido">

</div>-->


<div class="fondo">


<h1 class="titulo_taller">Talleres registrados</h1>

<div class="input-group" style="width:215px;">
              <label for="" id="labelbuscar_calendario" style="display:flex;"> 
              <input id="buscar_calendario_ss" name = "buscar_calendario_ss"  type="text" Class="form-control" placeholder=" ">
              <span id="spanbuscar_calendario">Buscar por Calendario</span>   
            
                 <div class="input-group-append">
               <button id="btnbuscar_calendario_ss" class="btn btn-primary" type="button" > <span class="fa-solid fa-magnifying-glass"></span> </button>
               </div>
               </label>
              </div>

              
              <div id="datos_buscar_calendario_ss">

</div>


<table class="table-responsive " id="calendario_vigente">
    <thead>
<tr class="fila_principal">

    <td>Nombre del taller</td>
    <td>Calendario</td>
    <td>Capacidad</td>
    <td>Turno</td>
    <td>Tipo</td>
    <td>Dia</td>
    <td>Registrados</td>
    <td>Faltantes</td>
</tr>
</thead>
<?php  foreach($resultado as $taller):  ?>

    <!--taller1.2.php?idtaller='<?php //echo $taller['NombreTaller']?>'-->
   

<tr class="filas_secundarias" id="color_filas" >

    <td> <a href="constancias_servicio_social.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"> <?php echo utf8_encode($taller['NombreTaller']);?> </a></td>
    <td> <a href="constancias_servicio_social.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"> <?php echo utf8_encode($taller['Calendario']);?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo  utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Capacidad']?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Turno']?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo  utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Tipo']?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo  utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Dia']?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo  utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Registrados']?></a></td>
    <td><a href="constancias_servicio_social.php?tallerista=<?php echo  utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo  utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>&fecha_inicio=<?php echo $taller['Fecha_inicio']?>&fecha_final=<?php echo $taller['Fecha_final']?>"><?php echo $taller['Lugares_Faltantes']?></a></td>
    <td><a  href="lista_pdf.php?tallerista=<?php echo utf8_encode($taller['NombreTallerista'])?>&taller=<?php echo utf8_encode($taller['NombreTaller'])?>&calendario=<?php echo $taller['Calendario']?>&turno=<?php echo $taller['Turno']?>&dia=<?php echo $taller['Dia']?>"><button type='submit' class="btn btn-primary">Lista</button></a></td>
  </tr>
</a>

<?php   endforeach; ?>

</table>



</div>




<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="../assets/js/Buscar.js"></script>

<!--<script src="../assets/js/jquery-3.6.0.min.js"></script>-->

<?php
// Comprobar si $_SESSION["timeout"] está establecida
/*if(isset($_SESSION["timeout"])){
  // Calcular el tiempo de vida de la sesión (TTL = Time To Live)
  $sessionTTL = time() - $_SESSION["timeout"];
  if($sessionTTL > $inactividad){
      session_destroy();
      echo "<script> 

      $.ajax({
        url: 'tiempo_excedido_modal.php',
      type: 'POST',
      dataType: 'html',
      //data: {buscar: buscar},
      
      })
      .done(function(respuesta){
        $('#modal_tiempo_excedido').html(respuesta);
      })
      .fail(function(){
      
      })
      
      </script>";
     
      echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";
  }
}*/

?>

</body>
</html>
<?php $conexion = null;?>
