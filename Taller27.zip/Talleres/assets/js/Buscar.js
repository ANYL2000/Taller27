function buscar_ahora(buscar){
    //var parametros = ("buscar":buscar);

    console.log(buscar);

    $.ajax({
      url: 'buscador.php',
    type: 'POST',
    dataType: 'html',
    data: {buscar: buscar},
    
    })
    .done(function(respuesta){
      $('#datos_buscador').html(respuesta);
    })
    .fail(function(){
    
    })
    
    }

    $(document).on('click','#buscar',function(){
        var valor = $('#codigo').val();
        if(valor!=""){
            buscar_ahora(valor);
        }else{
           // buscar_ahora();
        }
        });


        ////////////////////////////////////////////

        function buscar_ahora_calendario(buscar){
          //var parametros = ("buscar":buscar);
      
          console.log(buscar);
      
          $.ajax({
            url: 'buscar_calendario.php',
          type: 'POST',
          dataType: 'html',
          data: {buscar: buscar},
          
          })
          .done(function(respuesta){
            $('#calendario_vigente').hide();
            $('#datos_buscar_calendario').html(respuesta);
          })
          .fail(function(){
          
          })
          
          }
      
          $(document).on('click','#btnbuscar_calendario',function(){
              var valor = $('#buscar_calendario').val();
              if(valor!=""){
                buscar_ahora_calendario(valor);
              }else{
               // buscar_ahora_calendario();
              }
              });

                ////////////////////////////////////////////

        function buscar_ahora_calendario_ss(buscar){
          //var parametros = ("buscar":buscar);
      
          console.log(buscar);
      
          $.ajax({
            url: 'buscar_calendario_servicio_social.php',
          type: 'POST',
          dataType: 'html',
          data: {buscar: buscar},
          
          })
          .done(function(respuesta){
            $('#calendario_vigente').hide();
            $('#datos_buscar_calendario_ss').html(respuesta);
          })
          .fail(function(){
          
          })
          
          }
      
          $(document).on('click','#btnbuscar_calendario_ss',function(){
              var valor = $('#buscar_calendario_ss').val();
              if(valor!=""){
                buscar_ahora_calendario_ss(valor);
              }else{
               // buscar_ahora_calendario_ss();
              }
              });


                 ////////////////////////////////////////////

        function buscar_ahora_folio(buscar){
          //var parametros = ("buscar":buscar);
      
          console.log(buscar);
      
          $.ajax({
            url: 'buscar_folios_talleres.php',
          type: 'POST',
          dataType: 'html',
          data: {buscar: buscar},
          
          })
          .done(function(respuesta){
           
            $('#datos_buscar_folio').html(respuesta);
          })
          .fail(function(){
          
          })
          
          }
      
          $(document).on('click','#btnbuscar_folio',function(){
              var valor = $('#buscar_folio').val();
             
              if(valor!=""){
                buscar_ahora_folio(valor);
              }else{
                    
                $('#datos_buscar_folio').html("Escriba el folio");
              }
              });